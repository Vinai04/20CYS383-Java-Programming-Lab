package com.amrita.jpl.cys21084.ex;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Address book application
 * @author Vinayak
 * @version 1.0
 */
public class AddressBook extends JFrame {

    private JTable contactTable;
    private DefaultTableModel tableModel;

    private JTextField nameField;
    private JTextField phoneField;
    private JTextField emailField;

    private List<Contact> contacts;

    /**
     * Constructs the U21CYSAddressBook frame.
     * Initializes the GUI components and sets up the layout.
     */
    public AddressBook() {
        setTitle("21CYS Address Book");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the main panel and set layout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Create the form panel and add labels and text fields
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2));

        JLabel l1 = new JLabel("Name: ");
        formPanel.add(l1, BorderLayout.NORTH);

        nameField = new JTextField(30);
        formPanel.add(nameField, BorderLayout.NORTH);

        JLabel l2 = new JLabel("Phone Number: ");
        formPanel.add(l2, BorderLayout.NORTH);

        phoneField = new JTextField(30);
        formPanel.add(phoneField, BorderLayout.NORTH);

        JLabel l3 = new JLabel("Email: ");
        formPanel.add(l3, BorderLayout.NORTH);

        emailField = new JTextField(30);
        formPanel.add(emailField, BorderLayout.NORTH);

        // Create the button panel and add buttons
        JPanel buttonPanel = new JPanel();

        JButton add = new JButton("Add");
        buttonPanel.add(add);

        contacts = new ArrayList<>();
        add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddContact();
            }
        });

        JButton edit = new JButton("Edit");
        buttonPanel.add(edit);

        edit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = contactTable.getSelectedRow();
                if (selectedRow >= 0) {
                    Contact contact = contacts.get(selectedRow);
                    EditContact(contact);
                }
                else {
                    JLabel error = new JLabel("Please select a contact to edit! ");
                    formPanel.add(error, BorderLayout.SOUTH);
                }

            }
        });

        JButton delete = new JButton("Delete");
        buttonPanel.add(delete);

        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = contactTable.getSelectedRow();
                if (selectedRow >= 0) {
                    contacts.remove(selectedRow);
                    tableModel.removeRow(selectedRow);
                }

                else {
                    JLabel error = new JLabel("Please select a contact to delete! ");
                    formPanel.add(error, BorderLayout.SOUTH);
                }

            }
        });

        // Create the table with default table model
        tableModel = new DefaultTableModel(new Object[]{"Name", "Phone Number", "Email"}, 0);
        contactTable = new JTable(tableModel);

        // Create the scroll pane and add the table to it
        JScrollPane scrollPane = new JScrollPane(contactTable);



        // Add scroll pane, form panel, and button panel to the main panel
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the main panel to the content pane
        Container container = getContentPane();
        container.add(mainPanel);

        pack();
        setLocationRelativeTo(null); // Center the frame on the screen
    }

    class Contact {
        private String name;
        private String phoneNumber;
        private String email;

        public Contact(String name, String phoneNumber, String email) {
            this.name = name;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

    private void AddContact() {
        String name = nameField.getText().trim();
        String phoneNumber = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (!name.isEmpty() && isValidPhoneNumber(phoneNumber) && isValidEmail(email)) {
            Contact contact = new Contact(name, phoneNumber, email);
            contacts.add(contact);
            tableModel.addRow(new Object[]{name, phoneNumber, email});
        }

    }

    private void EditContact(Contact contact) {
        String name = nameField.getText().trim();
        String phoneNumber = phoneField.getText().trim();
        String email = emailField.getText().trim();

        if (!name.isEmpty() && isValidPhoneNumber(phoneNumber) && isValidEmail(email)) {
            contact.setName(name);
            contact.setPhoneNumber(phoneNumber);
            contact.setEmail(email);
            int row = contacts.indexOf(contact);
            tableModel.setValueAt(name, row, 0);
            tableModel.setValueAt(phoneNumber, row, 1);
            tableModel.setValueAt(email, row, 2);
        }

    }

    /**
     * Validates a phone number.
     *
     * @param phone the phone number to validate
     * @return true if the phone number is valid, false otherwise
     */
    private boolean isValidPhoneNumber(String phone) {
        // Perform validation logic for phone number (e.g., length, format, etc.)
        return true;
    }

    /**
     * Validates an email address.
     *
     * @param email the email address to validate
     * @return true if the email address is valid, false otherwise
     */
    private boolean isValidEmail(String email) {
        // Perform validation logic for email (e.g., format, etc.)
        return true;
    }

    /**
     * Clears the form fields.
     */
    private void clearFormFields() {

    }

    /**
     * ActionListener for the Add button.
     * Adds a new contact to the address book.
     */
    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

        }
    }

    /**
     * ActionListener for the Edit button.
     * Edits an existing contact in the address book.
     */
    private class EditButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

        }
    }

    /**
     * ActionListener for the Delete button.
     * Deletes a contact from the address book.
     */
    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

        }
    }

    /**
     * Entry point of the application.
     * Creates and displays the U21CYSAddressBook frame.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AddressBook().setVisible(true);
            }
        });
    }
}

