package com.amrita.jpl.cys21084.ex;
import java.util.Scanner;

import java.io.*;
import java.net.*;

/**
 * @author Vinayak
 * @version 0.5
 */

public class SimpleClient {
    /**
     * The main method is the entry point of the program.
     * It establishes a connection to the server, sends a message, and closes the connection.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            // Create a socket and connect to the server at "localhost" on port 2444
            Socket s = new Socket("localhost", 2444);
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            String str;
            Scanner myObj = new Scanner(System.in);

            do {
                // Create a DataInputStream to receive messages from the client



                // Read the message from the client
                System.out.println("Waiting for message from Server......");
                str = dis.readUTF();

                System.out.println("Message from Server: " + str);

                if(str.equals("exit"))
                {
                    break;
                }

                System.out.println("Enter a message for the Server:");
                String data = myObj.nextLine();


                // Send a message to the server
                System.out.println("Sending the message to Server.");
                dout.writeUTF(data);

                dout.flush();

            }while(true);

            // Close the output stream and the socket
            dis.close();
            dout.close();
            s.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}