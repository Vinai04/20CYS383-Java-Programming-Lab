package com.amrita.jpl.cys21084.pract.file;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class filewriter {
    public static void main(String[] args) {
        try {
            FileWriter mywrite = new FileWriter("20cys383.txt");
            mywrite.write("Just In");
            mywrite.close();
        } catch (IOException e) {
            System.out.println("[ERROR] Input Output Exception");
            e.printStackTrace();
        }
    }
}