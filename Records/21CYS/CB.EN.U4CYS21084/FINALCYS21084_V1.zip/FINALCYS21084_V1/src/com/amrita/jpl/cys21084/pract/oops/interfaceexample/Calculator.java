package com.amrita.jpl.cys21084.pract.oops.interfaceexample;
/**
 * @author Vinayak-CYS21084
 */

public interface Calculator {
    double add(double var1, double var3);

    double subtract(double var1, double var3);

    double multiply(double var1, double var3);

    double divide(double var1, double var3);
}
