package com.amrita.jpl.cys21084.pract.file;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class filereader {
    public static void main(String[] args) {
        File myfile = new File("20cys383.txt");
        Scanner myread = new Scanner("20cys383.txt");
        while(myread.hasNextLine()){
            String data = myread.nextLine();
            System.out.println(data);
        }
        myread.close();
    }
}