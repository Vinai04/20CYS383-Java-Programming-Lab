package com.amrita.jpl.cys21084.p1;
import java.util.Scanner;

/**
 * @author Vinayak CB.EN.U4CYS21084
 */

class Options {

    /**
     * @param n Calculating the factorial of a number
     */
    int fact(int n){
        int factorial=1;
        for(int i=1;i<=n;i++){
            factorial*=i;
        }

        return factorial;
    }

    /**
     * @param n Calculating the sum of n numbers
     */
    int sum_n_no(int n){
        int sum = 0;
        for(int i=1;i<=n;i++){
            sum+=i;
        }

        return sum;
    }

    /**
     * @param n Printing the fibonacci series till a given limit
     */
    void fibo(int n){

        int a=0,b=1,c;

        System.out.print(a+" "+b);

        for(int i=2;i<n;++i)
        {
            c=a+b;
            System.out.print(" "+c);
            a=b;
            b=c;
        }
    }

    /**
     * @param n Checking a number is prime or not
     */
    int prime_test(int n){
        int flag = 0;
        for(int i=2;i<n/2;i++){
            if(n%i==0) {
                flag = 1;
                break;
            }
        }

        return flag;
    }

}

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Options obj = new Options();

        int n, result;
        System.out.println("1.Factorial of a number");
        System.out.println("2.Fibonacci series");
        System.out.println("3.Sum of n numbers");
        System.out.println("4.Prime test");
        System.out.print("Enter your choice: ");
        int choice = input.nextInt();

        switch(choice){

            case 1:
                System.out.print("Enter the number: ");
                n = input.nextInt();
                if(n<0){
                    System.out.println("Enter a positive number!");
                    break;
                }
                else{
                    result = obj.fact(n);
                    System.out.println(result);
                    break;
                }

            case 2:
                System.out.print("Enter the number: ");
                n = input.nextInt();
                if(n<0){
                    System.out.println("Enter a positive number!");
                    break;
                }
                else{
                    obj.fibo(n);
                    break;
                }

            case 3:
                System.out.print("Enter the number: ");
                n = input.nextInt();
                if(n<0){
                    System.out.println("Enter a positive number!");
                    break;
                }
                else{
                    result = obj.sum_n_no(n);
                    System.out.println(result);
                    break;
                }

            case 4:
                System.out.print("Enter the number: ");
                n = input.nextInt();
                if(n<0){
                    System.out.println("Enter a positive number!");
                    break;
                }
                else{
                    result = obj.prime_test(n);
                    if(result==0){
                        System.out.println("It is prime number");
                    }
                    else{
                        System.out.println("It is not prime number");
                    }
                    break;
                }

            default:
                System.out.println("Invalid Choice!");
                break;
        }

    }
}