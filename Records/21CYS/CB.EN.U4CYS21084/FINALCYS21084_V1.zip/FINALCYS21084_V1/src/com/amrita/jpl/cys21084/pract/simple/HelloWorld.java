package com.amrita.jpl.cys21084.pract.simple;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

    public void add(){

    }
}