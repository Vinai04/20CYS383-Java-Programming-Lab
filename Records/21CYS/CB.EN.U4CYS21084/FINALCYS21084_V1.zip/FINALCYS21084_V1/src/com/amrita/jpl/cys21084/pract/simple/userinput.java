package com.amrita.jpl.cys21084.pract.simple;
import java.util.Scanner;

class Lamp {


}

/**
 * @author vinay
 */

public class userinput{

    /**
     * @param args Default argument of main function
     */
    public static void main(String[] args){

        Scanner input = new Scanner(System.in);

        String custom = input.nextLine();

        System.out.println(custom);

        Lamp obj = new Lamp();

        input.close();
    }
}